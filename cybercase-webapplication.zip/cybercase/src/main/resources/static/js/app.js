(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const reveals = document.querySelectorAll('.reveal');
  if (!reduceMotion && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
    }), { threshold: 0.08 });
    reveals.forEach(el => observer.observe(el));
  } else reveals.forEach(el => el.classList.add('is-visible'));
  document.querySelectorAll('form').forEach(form => form.addEventListener('submit', () => {
    const button = form.querySelector('button[type="submit"]');
    if (button && !button.disabled) { button.dataset.originalText = button.textContent; button.classList.add('is-loading'); button.setAttribute('aria-busy','true'); }
  }));
  const incidentInput = document.querySelector('#incidentAt');
  if (incidentInput && !incidentInput.value) {
    const now = new Date(); now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    incidentInput.value = now.toISOString().slice(0,16);
  }
})();
