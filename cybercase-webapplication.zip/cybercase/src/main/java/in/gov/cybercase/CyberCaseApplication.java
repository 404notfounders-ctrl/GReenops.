package in.gov.cybercase;

import in.gov.cybercase.entity.AppUser;
import in.gov.cybercase.repository.AppUserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CyberCaseApplication {
    public static void main(String[] args) { SpringApplication.run(CyberCaseApplication.class, args); }

    // Environment/profile-based bootstrap is only for local demonstrations. Existing accounts are never overwritten.
    @Bean CommandLineRunner provisionDemoAccounts(AppUserRepository users, PasswordEncoder encoder,
            @Value("${app.bootstrap.admin-username:}") String adminUsername,
            @Value("${app.bootstrap.admin-password:}") String adminPassword,
            @Value("${app.bootstrap.investigator-username:}") String investigatorUsername,
            @Value("${app.bootstrap.investigator-password:}") String investigatorPassword,
            @Value("${app.bootstrap.reviewer-username:}") String reviewerUsername,
            @Value("${app.bootstrap.reviewer-password:}") String reviewerPassword) {
        return args -> {
            createAccount(users, encoder, adminUsername, adminPassword, "ADMIN");
            createAccount(users, encoder, investigatorUsername, investigatorPassword, "INVESTIGATOR");
            createAccount(users, encoder, reviewerUsername, reviewerPassword, "REVIEWER");
        };
    }

    private void createAccount(AppUserRepository users, PasswordEncoder encoder, String username, String password, String role) {
        if (username == null || username.isBlank() || password == null || password.length() < 14) {
            return;
        }

        // This method receives demo credentials only from application-dev.properties or explicit
        // bootstrap environment variables. Existing non-demo accounts are never modified.
        var existing = users.findByUsername(username);
        if (existing.isPresent()) {
            AppUser account = existing.get();
            if ("admin.demo".equals(username) || "staff.demo".equals(username) || "user.demo".equals(username)) {
                account.updateDemoCredentials(encoder.encode(password), role);
                users.save(account);
                System.out.println("CyberCase: development demo credentials refreshed for " + username + " (" + role + ").");
            } else {
                System.out.println("CyberCase: account already exists for " + username + "; it was not changed.");
            }
            return;
        }

        users.save(new AppUser(username, encoder.encode(password), role));
        System.out.println("CyberCase: configured " + role + " account created for " + username + ".");
    }
}
