package in.gov.cybercase.repository;
import in.gov.cybercase.entity.Complaint; import org.springframework.data.domain.Page; import org.springframework.data.domain.Pageable; import org.springframework.data.jpa.repository.JpaRepository; import org.springframework.data.jpa.repository.Query; import org.springframework.data.repository.query.Param; import java.util.Optional;
public interface ComplaintRepository extends JpaRepository<Complaint,Long>{
 Optional<Complaint> findByReferenceNumber(String referenceNumber);
 @Query("select c from Complaint c where (:q is null or :q='' or lower(c.referenceNumber) like lower(concat('%',:q,'%')) or lower(c.title) like lower(concat('%',:q,'%')) or lower(c.indicator) like lower(concat('%',:q,'%'))) and (:status is null or :status='' or c.status=:status) and (:category is null or :category='' or c.category=:category) order by c.createdAt desc")
 Page<Complaint> search(@Param("q") String q,@Param("status") String status,@Param("category") String category,Pageable pageable);
 long countByStatus(String status); long countByPriority(String priority); long countByCategory(String category);
}
