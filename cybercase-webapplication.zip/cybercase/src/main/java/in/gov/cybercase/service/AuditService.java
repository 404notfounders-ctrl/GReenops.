package in.gov.cybercase.service;
import in.gov.cybercase.entity.AuditLog; import in.gov.cybercase.repository.AuditLogRepository; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;
@Service public class AuditService {private final AuditLogRepository logs; public AuditService(AuditLogRepository logs){this.logs=logs;} @Transactional public void record(String actor,String action,String type,String ref,String summary){logs.save(new AuditLog(actor,action,type,ref,summary));}}
