package in.gov.cybercase.integration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.time.Instant;
import java.util.regex.Pattern;

@Service
public class ThreatIntelligenceService {
    private static final Pattern DOMAIN = Pattern.compile(
            "(?i)^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z]{2,63}$");

    private final String apiKey;
    private final RestClient client;
    private final ObjectMapper mapper;

    public ThreatIntelligenceService(
            @Value("${app.threat-intel.urlhaus-api-key:}") String apiKey,
            ObjectMapper mapper) {
        this.apiKey = apiKey;
        this.mapper = mapper;
        this.client = RestClient.builder()
                .baseUrl("https://urlhaus-api.abuse.ch/v1/host/")
                .build();
    }

    public VerificationResult checkDomain(String raw) {
        String value = raw == null ? "" : raw.trim().toLowerCase()
                .replaceFirst("^https?://", "").split("[/?:#]", 2)[0];
        if (!DOMAIN.matcher(value).matches()) {
            return new VerificationResult("URLhaus", "", "UNSUPPORTED",
                    "Enter a valid domain name only; arbitrary URLs and private network addresses are not fetched.",
                    "https://urlhaus.abuse.ch/", Instant.now());
        }
        if (apiKey == null || apiKey.isBlank()) {
            return new VerificationResult("URLhaus", value, "UNCONFIGURED",
                    "No live lookup was performed. Configure URLHAUS_API_KEY to enable authorized URLhaus API checks.",
                    "https://urlhaus.abuse.ch/", Instant.now());
        }
        try {
            String body = client.post()
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .header("Auth-Key", apiKey)
                    .body("host=" + value)
                    .retrieve().body(String.class);
            JsonNode response = mapper.readTree(body == null ? "{}" : body);
            String queryStatus = response.path("query_status").asText("");
            String status;
            String explanation;
            if ("ok".equalsIgnoreCase(queryStatus)) {
                status = "POTENTIAL_MATCH";
                explanation = "URLhaus returned records for this domain. Review the source record and context; this is an investigative lead, not proof of criminal activity.";
            } else if ("no_results".equalsIgnoreCase(queryStatus)) {
                status = "NO_MATCH_FOUND";
                explanation = "URLhaus reported no matching records in this response. This does not establish that the domain is safe.";
            } else {
                status = "UNAVAILABLE";
                explanation = "URLhaus returned an unexpected response. No verification conclusion was made.";
            }
            return new VerificationResult("URLhaus", value, status, explanation,
                    "https://urlhaus.abuse.ch/", Instant.now());
        } catch (RestClientException | JsonProcessingException ex) {
            return new VerificationResult("URLhaus", value, "UNAVAILABLE",
                    "The authorized external source could not be reached or returned an unreadable response. No verification conclusion was made.",
                    "https://urlhaus.abuse.ch/", Instant.now());
        }
    }
}
