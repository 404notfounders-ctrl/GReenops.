package in.gov.cybercase.integration;
import java.time.Instant;
public record VerificationResult(String source,String indicator,String status,String explanation,String sourceUrl,Instant checkedAt) {}
