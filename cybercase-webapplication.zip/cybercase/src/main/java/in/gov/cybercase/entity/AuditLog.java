package in.gov.cybercase.entity;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="audit_log",indexes=@Index(name="idx_audit_created",columnList="createdAt")) public class AuditLog {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,length=80) private String actor;
 @Column(nullable=false,length=60) private String action;
 @Column(length=40) private String recordType;
 @Column(length=80) private String recordReference;
 @Column(length=500) private String summary;
 @Column(nullable=false,updatable=false) private Instant createdAt=Instant.now();
 protected AuditLog(){} public AuditLog(String actor,String action,String recordType,String recordReference,String summary){this.actor=actor;this.action=action;this.recordType=recordType;this.recordReference=recordReference;this.summary=summary;}
 public Long getId(){return id;} public String getActor(){return actor;} public String getAction(){return action;} public String getRecordType(){return recordType;} public String getRecordReference(){return recordReference;} public String getSummary(){return summary;} public Instant getCreatedAt(){return createdAt;}
}
