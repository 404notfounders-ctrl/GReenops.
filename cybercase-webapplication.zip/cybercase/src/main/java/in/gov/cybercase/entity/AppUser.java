package in.gov.cybercase.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity @Table(name="app_user", indexes=@Index(name="idx_user_username", columnList="username", unique=true))
public class AppUser {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false, unique=true, length=80) private String username;
    @Column(nullable=false, length=100) private String passwordHash;
    @Column(nullable=false, length=20) private String role;
    @Column(nullable=false) private Instant createdAt=Instant.now();
    protected AppUser() {}
    public AppUser(String username, String passwordHash, String role) { this.username=username; this.passwordHash=passwordHash; this.role=role; }
    public Long getId(){return id;} public String getUsername(){return username;} public String getPasswordHash(){return passwordHash;} public String getRole(){return role;} public Instant getCreatedAt(){return createdAt;}
    public void updateDemoCredentials(String passwordHash, String role) { this.passwordHash = passwordHash; this.role = role; }
}
