package in.gov.cybercase.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity @Table(name="complaint", indexes={@Index(name="idx_complaint_ref", columnList="referenceNumber", unique=true),@Index(name="idx_complaint_status",columnList="status"),@Index(name="idx_complaint_category",columnList="category")})
public class Complaint {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false,unique=true,length=24) private String referenceNumber;
    @NotBlank @Size(max=140) @Column(nullable=false,length=140) private String title;
    @NotBlank @Size(max=5000) @Column(nullable=false,length=5000) private String description;
    @NotBlank @Column(nullable=false,length=40) private String category;
    @NotNull @Column(nullable=false) private LocalDateTime incidentAt;
    @NotBlank @Column(nullable=false,length=30) private String priority="NORMAL";
    @NotBlank @Column(nullable=false,length=30) private String status="SUBMITTED";
    @DecimalMin("0.00") @Digits(integer=12,fraction=2) private BigDecimal reportedLoss;
    @Size(max=3) private String currency="INR";
    @Size(max=500) private String indicator;
    @Size(max=80) private String assignedOfficer;
    @Column(nullable=false,updatable=false) private Instant createdAt=Instant.now();
    @Column(nullable=false) private Instant updatedAt=Instant.now();
    @Column(nullable=false,length=80) private String createdBy;
    @PrePersist void onCreate(){ if(referenceNumber==null) referenceNumber="CC-"+UUID.randomUUID().toString().substring(0,8).toUpperCase(); if(createdAt==null)createdAt=Instant.now(); updatedAt=Instant.now(); }
    @PreUpdate void onUpdate(){updatedAt=Instant.now();}
    protected Complaint() {}
    public Complaint(String title,String description,String category,LocalDateTime incidentAt,String priority,BigDecimal reportedLoss,String currency,String indicator,String createdBy){this.title=title;this.description=description;this.category=category;this.incidentAt=incidentAt;this.priority=priority;this.reportedLoss=reportedLoss;this.currency=currency;this.indicator=indicator;this.createdBy=createdBy;}
    public Long getId(){return id;} public String getReferenceNumber(){return referenceNumber;} public String getTitle(){return title;} public String getDescription(){return description;} public String getCategory(){return category;} public LocalDateTime getIncidentAt(){return incidentAt;} public String getPriority(){return priority;} public String getStatus(){return status;} public BigDecimal getReportedLoss(){return reportedLoss;} public String getCurrency(){return currency;} public String getIndicator(){return indicator;} public String getAssignedOfficer(){return assignedOfficer;} public Instant getCreatedAt(){return createdAt;} public Instant getUpdatedAt(){return updatedAt;} public String getCreatedBy(){return createdBy;}
    public void setStatus(String status){this.status=status;} public void setAssignedOfficer(String assignedOfficer){this.assignedOfficer=assignedOfficer;}
}
