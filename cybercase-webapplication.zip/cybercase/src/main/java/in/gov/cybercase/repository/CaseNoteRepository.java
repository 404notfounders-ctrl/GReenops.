package in.gov.cybercase.repository;
import in.gov.cybercase.entity.CaseNote; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface CaseNoteRepository extends JpaRepository<CaseNote,Long>{ List<CaseNote> findByComplaintIdOrderByCreatedAtDesc(Long complaintId); }
