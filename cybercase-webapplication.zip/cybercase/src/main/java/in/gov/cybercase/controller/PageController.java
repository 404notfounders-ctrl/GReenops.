package in.gov.cybercase.controller;
import in.gov.cybercase.entity.*; import in.gov.cybercase.repository.*; import in.gov.cybercase.service.*; import in.gov.cybercase.integration.*; import jakarta.validation.constraints.*; import org.springframework.security.core.Authentication; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.validation.BindingResult; import org.springframework.web.bind.annotation.*; import org.springframework.web.servlet.mvc.support.RedirectAttributes; import jakarta.validation.Valid; import java.math.BigDecimal; import java.time.LocalDateTime;
@Controller public class PageController {
 private final ComplaintService service; private final ComplaintRepository complaints; private final AuditLogRepository audits; private final ThreatIntelligenceService intel; private final AuditService audit;
 public PageController(ComplaintService service,ComplaintRepository complaints,AuditLogRepository audits,ThreatIntelligenceService intel,AuditService audit){this.service=service;this.complaints=complaints;this.audits=audits;this.intel=intel;this.audit=audit;}
 @GetMapping("/login") public String login(){return "login";}
 @GetMapping("/") public String dashboard(Authentication auth) {
  boolean admin = auth.getAuthorities().stream().anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
  boolean investigator = auth.getAuthorities().stream().anyMatch(a -> "ROLE_INVESTIGATOR".equals(a.getAuthority()));
  return "redirect:" + (admin ? "/admin/dashboard" : investigator ? "/staff/dashboard" : "/reviewer/dashboard");
 }
 @GetMapping({"/admin/dashboard", "/staff/dashboard", "/reviewer/dashboard"}) public String roleDashboard(Model model, Authentication auth) {
  model.addAttribute("currentRole", auth.getAuthorities().stream().findFirst().map(a -> a.getAuthority().replace("ROLE_", "")).orElse("USER"));
  model.addAttribute("metrics", service.metrics());
  model.addAttribute("recent", complaints.findAll(org.springframework.data.domain.PageRequest.of(0, 6, org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.DESC, "createdAt"))).getContent());
  model.addAttribute("activities", audits.findTop12ByOrderByCreatedAtDesc());
  return "dashboard";
 }
 @GetMapping("/complaints") public String list(@RequestParam(defaultValue="") String q,@RequestParam(defaultValue="") String status,@RequestParam(defaultValue="") String category,@RequestParam(defaultValue="0") int page,Model model){model.addAttribute("results",service.search(q,status,category,page));model.addAttribute("q",q);model.addAttribute("status",status);model.addAttribute("category",category);model.addAttribute("page",page);return "complaints";}
 @GetMapping("/complaints/new") public String newComplaint(){return "complaint-form";}
 @PostMapping("/complaints") public String create(@RequestParam @NotBlank @Size(max=140) String title,@RequestParam @NotBlank @Size(max=5000) String description,@RequestParam String category,@RequestParam @NotNull LocalDateTime incidentAt,@RequestParam(defaultValue="NORMAL") String priority,@RequestParam(required=false) BigDecimal reportedLoss,@RequestParam(defaultValue="INR") String currency,@RequestParam(required=false) @Size(max=500) String indicator,Authentication auth,RedirectAttributes flash){try{Complaint c=service.create(title,description,category,incidentAt,priority,reportedLoss,currency,indicator,auth.getName());flash.addFlashAttribute("success","Complaint recorded: "+c.getReferenceNumber());return "redirect:/complaints/"+c.getId();}catch(Exception ex){flash.addFlashAttribute("error",ex.getMessage());return "redirect:/complaints/new";}}
 @GetMapping("/complaints/{id}") public String detail(@PathVariable Long id,Model model){Complaint c=service.find(id).orElseThrow();model.addAttribute("c",c);model.addAttribute("notes",service.notes(id));return "complaint-detail";}
 @PostMapping("/complaints/{id}/workflow") public String workflow(@PathVariable Long id,@RequestParam String status,@RequestParam(required=false) String assignedOfficer,Authentication auth,RedirectAttributes flash){try{service.updateWorkflow(id,status,assignedOfficer,auth.getName());flash.addFlashAttribute("success","Case workflow updated.");}catch(Exception e){flash.addFlashAttribute("error",e.getMessage());}return "redirect:/complaints/"+id;}
 @PostMapping("/complaints/{id}/notes") public String note(@PathVariable Long id,@RequestParam @NotBlank @Size(max=4000) String body,Authentication auth,RedirectAttributes flash){try{service.addNote(id,body,auth.getName());flash.addFlashAttribute("success","Investigation note saved.");}catch(Exception e){flash.addFlashAttribute("error","Unable to save note.");}return "redirect:/complaints/"+id;}
 @GetMapping("/intelligence") public String intelligence(Model model){
  model.addAttribute("cases", complaints.findAll(org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.DESC,"createdAt")));
  return "intelligence";
 }
 @GetMapping("/innovation") public String innovation(Model model, Authentication auth) {
  java.util.List<Complaint> all = complaints.findAll(org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.DESC, "createdAt"));
  java.util.List<Complaint> urgentUnassigned = all.stream().filter(c -> "URGENT".equals(c.getPriority()) && (c.getAssignedOfficer() == null || c.getAssignedOfficer().isBlank()) && !java.util.Set.of("RESOLVED", "CLOSED").contains(c.getStatus())).toList();
  java.util.Map<String, Long> repeatedIndicators = all.stream().filter(c -> c.getIndicator() != null && !c.getIndicator().isBlank()).collect(java.util.stream.Collectors.groupingBy(c -> c.getIndicator().trim().toLowerCase(), java.util.stream.Collectors.counting()));
  java.util.List<java.util.Map<String, Object>> recommendations = new java.util.ArrayList<>();
  for (Complaint c : urgentUnassigned) {
   recommendations.add(java.util.Map.of("kind", "URGENT_UNASSIGNED", "title", "Assign urgent case " + c.getReferenceNumber(), "reason", "This record is marked urgent and has no assigned officer.", "impact", 95, "effort", "Low", "complaint", c));
  }
  for (java.util.Map.Entry<String, Long> entry : repeatedIndicators.entrySet()) {
   if (entry.getValue() > 1) {
    Complaint sample = all.stream().filter(c -> c.getIndicator() != null && c.getIndicator().trim().equalsIgnoreCase(entry.getKey())).findFirst().orElse(null);
    if (sample != null) recommendations.add(java.util.Map.of("kind", "REPEATED_INDICATOR", "title", "Review repeated indicator", "reason", "The same indicator appears in " + entry.getValue() + " complaint records. This is a lead for human review, not proof of a connection.", "impact", Math.min(90, 55 + entry.getValue().intValue() * 5), "effort", "Medium", "complaint", sample));
   }
  }
  long active = all.stream().filter(c -> !java.util.Set.of("RESOLVED", "CLOSED").contains(c.getStatus())).count();
  long resolved = all.stream().filter(c -> "RESOLVED".equals(c.getStatus()) || "CLOSED".equals(c.getStatus())).count();
  model.addAttribute("recommendations", recommendations);
  model.addAttribute("activeCount", active);
  model.addAttribute("resolvedCount", resolved);
  model.addAttribute("totalCount", all.size());
  model.addAttribute("currentRole", auth.getAuthorities().stream().findFirst().map(a -> a.getAuthority().replace("ROLE_", "")).orElse("USER"));
  return "innovation";
 }
 @PostMapping("/innovation/act") public String actOnRecommendation(@RequestParam Long complaintId, @RequestParam String assignedOfficer, Authentication auth, RedirectAttributes flash) {
  try {
   if (assignedOfficer == null || assignedOfficer.isBlank() || assignedOfficer.trim().length() > 80) throw new IllegalArgumentException("Enter a valid officer username.");
   service.updateWorkflow(complaintId, "ASSIGNED", assignedOfficer.trim(), auth.getName());
   audit.record(auth.getName(), "INNOVATION_ACTION_CREATED", "COMPLAINT", String.valueOf(complaintId), "Recommendation converted to assignment");
   flash.addFlashAttribute("success", "Recommendation applied: case assigned to " + assignedOfficer.trim() + ".");
  } catch (Exception ex) { flash.addFlashAttribute("error", "Could not apply recommendation. Check the case and assignment details."); }
  return "redirect:/innovation";
 }
 @GetMapping("/verification") public String verification(){return "verification";}
 @PostMapping("/verification") public String verify(@RequestParam String domain,Authentication auth,Model model){VerificationResult result=intel.checkDomain(domain);audit.record(auth.getName(),"VERIFICATION_ATTEMPT","INDICATOR",result.indicator(),result.status()+" via "+result.source());model.addAttribute("result",result);model.addAttribute("domain",domain);return "verification";}
 @GetMapping("/reports.csv")
 @ResponseBody
 public org.springframework.http.ResponseEntity<String> csv(Authentication auth) {
     StringBuilder csv = new StringBuilder("reference,title,category,status,priority,created_at\r\n");
     complaints.findAll(org.springframework.data.domain.Sort.by("createdAt")).forEach(c -> csv
         .append(csvCell(c.getReferenceNumber())).append(',')
         .append(csvCell(c.getTitle())).append(',')
         .append(csvCell(c.getCategory())).append(',')
         .append(csvCell(c.getStatus())).append(',')
         .append(csvCell(c.getPriority())).append(',')
         .append(csvCell(c.getCreatedAt().toString())).append("\r\n"));

     audit.record(auth.getName(), "REPORT_EXPORTED", "REPORT", "complaints.csv",
         "Complaint register exported");
     return org.springframework.http.ResponseEntity.ok()
         .header("Content-Disposition", "attachment; filename=complaints.csv")
         .contentType(org.springframework.http.MediaType.parseMediaType("text/csv; charset=UTF-8"))
         .body(csv.toString());
 }

 private String csvCell(String value) {
     String cell = value == null ? "" : value.replace("\"", "\"\"");
     if (!cell.isEmpty() && "=+-@\t\r\n".indexOf(cell.charAt(0)) >= 0) {
         cell = "'" + cell;
     }
     return "\"" + cell + "\"";
 }

}
