package in.gov.cybercase.repository;
import in.gov.cybercase.entity.AuditLog; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface AuditLogRepository extends JpaRepository<AuditLog,Long>{ List<AuditLog> findTop12ByOrderByCreatedAtDesc(); }
