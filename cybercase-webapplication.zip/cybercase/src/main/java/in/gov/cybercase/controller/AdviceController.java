package in.gov.cybercase.controller;
import org.springframework.ui.Model; import org.springframework.web.bind.annotation.ControllerAdvice; import org.springframework.web.bind.annotation.ExceptionHandler; import jakarta.persistence.EntityNotFoundException;
@ControllerAdvice public class AdviceController { @ExceptionHandler({EntityNotFoundException.class}) public String notFound(Model model){model.addAttribute("message","That record could not be found or is no longer available.");return "error";} }
