package in.gov.cybercase.entity;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import java.time.Instant;
@Entity @Table(name="case_note") public class CaseNote {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false,fetch=FetchType.LAZY) @JoinColumn(name="complaint_id",nullable=false) private Complaint complaint;
 @Column(nullable=false,length=80) private String author;
 @NotBlank @Size(max=4000) @Column(nullable=false,length=4000) private String body;
 @Column(nullable=false,updatable=false) private Instant createdAt=Instant.now();
 protected CaseNote(){} public CaseNote(Complaint complaint,String author,String body){this.complaint=complaint;this.author=author;this.body=body;}
 public Long getId(){return id;} public Complaint getComplaint(){return complaint;} public String getAuthor(){return author;} public String getBody(){return body;} public Instant getCreatedAt(){return createdAt;}
}
