package in.gov.cybercase.security;

import in.gov.cybercase.service.UserDetailsServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/login", "/css/**", "/js/**", "/favicon.ico", "/error").permitAll()
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/staff/**").hasRole("INVESTIGATOR")
                .requestMatchers("/reviewer/**").hasRole("REVIEWER")
                .requestMatchers("/reports.csv").hasAnyRole("ADMIN", "REVIEWER")
                .requestMatchers(org.springframework.http.HttpMethod.POST, "/innovation/act").hasAnyRole("ADMIN", "INVESTIGATOR")
                .requestMatchers("/intelligence/**", "/innovation").hasAnyRole("ADMIN", "INVESTIGATOR", "REVIEWER")
                .requestMatchers(org.springframework.http.HttpMethod.GET, "/complaints").authenticated()
                .requestMatchers(org.springframework.http.HttpMethod.POST, "/complaints").hasAnyRole("ADMIN", "INVESTIGATOR")
                .requestMatchers("/complaints/new").hasAnyRole("ADMIN", "INVESTIGATOR")
                .requestMatchers("/complaints/*/workflow", "/complaints/*/notes").hasAnyRole("ADMIN", "INVESTIGATOR")
                .anyRequest().authenticated())
            .formLogin(form -> form.loginPage("/login").successHandler((request, response, authentication) -> {
                boolean admin = authentication.getAuthorities().stream().anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
                boolean investigator = authentication.getAuthorities().stream().anyMatch(a -> "ROLE_INVESTIGATOR".equals(a.getAuthority()));
                response.sendRedirect(admin ? "/admin/dashboard" : investigator ? "/staff/dashboard" : "/reviewer/dashboard");
            }).permitAll())
            .logout(logout -> logout.logoutSuccessUrl("/login?logout").invalidateHttpSession(true).deleteCookies("JSESSIONID"))
            .csrf(Customizer.withDefaults())
            .headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()).contentTypeOptions(Customizer.withDefaults()))
            .build();
    }

    @Bean
    PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(12); }
}
