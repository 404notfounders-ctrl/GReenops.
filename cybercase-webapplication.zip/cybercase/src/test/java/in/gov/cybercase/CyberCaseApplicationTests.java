package in.gov.cybercase;
import org.junit.jupiter.api.Test; import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest class CyberCaseApplicationTests { @Test void contextLoads() {} }
